"""네이버 뉴스 검색 API로 주제 관련 과거 기사 메타를 모은다.

기사 전문은 저장하지 않는다(저작권). 제목·언론사·날짜·링크만 남긴다.

실행 전 확인:
  1) .venv 가 활성화돼 있는가  (프롬프트 앞에 (.venv) 표시)
  2) .env 에 NAVER_CLIENT_ID / NAVER_CLIENT_SECRET 이 들어 있는가

실행:
  python .agents/skills/background-collect/collect_news.py
"""
import html, json, os, pathlib, re, time, urllib.parse, urllib.request
from collections import Counter
from email.utils import parsedate_to_datetime
from dotenv import load_dotenv

load_dotenv()

# ── 여기만 고쳐 쓰세요 ────────────────────────────────
QUERIES = ["해상풍력 인허가", "해상풍력 국산화", "해상풍력특별법"]
MAX_PER_QUERY = 300          # 네이버 API 상한: 질의당 1000건
SORT = "date"                # 최신순. 기간이 짧으면 "sim"(정확도순)으로 한 번 더
OUT = pathlib.Path("1_plan") / "background_raw.md"
# ────────────────────────────────────────────────────

try:
    CID = os.environ["NAVER_CLIENT_ID"]
    CSEC = os.environ["NAVER_CLIENT_SECRET"]
except KeyError as e:
    raise SystemExit(
        f"\n[설정 오류] .env 에 {e.args[0]} 가 없습니다.\n"
        "  1) 프로젝트 폴더에 .env 파일이 있는지 확인하세요.\n"
        "  2) .env.example 을 복사해 .env 로 만들고 키를 채우세요.\n"
    )


def strip_tags(s):
    """검색어 강조용 <b> 태그와 HTML 엔티티를 걷어낸다."""
    return html.unescape(re.sub(r"<[^>]+>", "", s or "")).strip()


def to_date(pub_date):
    """네이버가 주는 RFC822 날짜를 YYYY-MM-DD로. 타임라인 정렬에 필요하다."""
    try:
        return parsedate_to_datetime(pub_date).strftime("%Y-%m-%d")
    except (TypeError, ValueError):
        return "0000-00-00"


def search(query, want):
    items, start = [], 1
    while len(items) < want and start <= 1000:
        qs = urllib.parse.urlencode(
            {"query": query, "display": 100, "start": start, "sort": SORT}
        )
        req = urllib.request.Request(
            f"https://openapi.naver.com/v1/search/news.json?{qs}",
            headers={"X-Naver-Client-Id": CID, "X-Naver-Client-Secret": CSEC},
        )
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                batch = json.loads(r.read().decode("utf-8")).get("items", [])
        except urllib.error.HTTPError as e:
            if e.code == 401:
                raise SystemExit(
                    "\n[인증 오류 401] 네이버 키가 틀렸거나 애플리케이션에 '검색' API가 "
                    "추가되지 않았습니다.\n  developers.naver.com > 내 애플리케이션 에서 확인하세요.\n"
                )
            raise
        if not batch:
            break
        items.extend(batch)
        start += 100
        time.sleep(0.1)          # 호출 한도를 지킨다
    return items[:want]


seen, rows = set(), []
for q in QUERIES:
    got = search(q, MAX_PER_QUERY)
    print(f"  {q}: {len(got)}건")
    for it in got:
        link = it.get("originallink") or it.get("link")
        if not link or link in seen:
            continue
        seen.add(link)
        rows.append({
            "date": to_date(it.get("pubDate", "")),
            "title": strip_tags(it.get("title")),
            "desc": strip_tags(it.get("description"))[:120],
            "link": link,
            "domain": urllib.parse.urlparse(link).netloc.replace("www.", ""),
        })

rows.sort(key=lambda r: r["date"], reverse=True)

OUT.parent.mkdir(parents=True, exist_ok=True)
lines = [
    "# 배경 자료 — 과거 기사 메타", "",
    f"검색어: {' / '.join(QUERIES)}",
    f"수집: {len(rows)}건 (중복 링크 제거 후)",
    f"기간: {rows[-1]['date']} ~ {rows[0]['date']}" if rows else "", "",
    "> 기사 전문은 저장하지 않는다. 확인은 링크로 원문에서 한다.", "",
]
for i, r in enumerate(rows, 1):
    lines += [
        f"## N{i:03d}  {r['title']}",
        f"- 매체: {r['domain']} | 일자: {r['date']}",
        f"- 요약: {r['desc']}",
        f"- 링크: {r['link']}", "",
    ]
OUT.write_text("\n".join(lines), encoding="utf-8")

print(f"\n저장: {OUT}  ({len(rows)}건)")
if rows:
    print(f"실제 기간: {rows[-1]['date']} ~ {rows[0]['date']}")
    print("  ※ 기간이 사안 대비 너무 짧으면 SORT 를 \"sim\" 으로 바꿔 한 번 더 돌리세요.")
print("매체 분포 상위 10:")
for dom, n in Counter(r["domain"] for r in rows).most_common(10):
    print(f"  {dom:<28} {n:>4}건")
