---
name: background-collect
description: 네이버 뉴스 검색 API로 주제 관련 과거 기사를 수집할 때 사용한다.
---
# 과거 기사 수집 절차
1. 주제를 쟁점별 검색어 3~5개로 나눈다. 한 덩어리 검색어는 결과가 좁아진다.
2. collect_news.py 상단의 QUERIES 를 그 검색어로 고친다.
3. .venv 활성화 후 실행한다:  python .agents/skills/background-collect/collect_news.py
4. 출력된 '실제 기간'을 확인한다. 사안 대비 너무 짧으면 스크립트의 SORT 를
   "date" → "sim" 으로 바꿔 한 번 더 돌리고, 결과를 합친다.
5. 기사 전문은 저장하지 않고 링크만 남긴다. API 호출 한도를 지킨다.

# 자주 나는 오류
- ModuleNotFoundError: .venv 가 활성화되지 않은 상태로 실행한 경우가 대부분이다.
- KeyError: 'NAVER_CLIENT_ID': .env 파일이 없거나 키 이름이 다르다.
- HTTP 401: 키가 틀렸거나 네이버 애플리케이션에 '검색' API가 추가되지 않았다.
