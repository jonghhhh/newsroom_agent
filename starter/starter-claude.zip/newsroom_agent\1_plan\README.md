# 1_plan — 1막(기획) 산출물 폴더

실습을 진행하면 이 폴더에 아래 파일들이 순서대로 쌓입니다.

| 파일 | 만드는 주체 | 내용 |
|---|---|---|
| `background_raw.md` | news-archivist | 과거 기사 메타 (제목·매체·일자·링크) |
| `background_web.md` | web-researcher | 웹 배경 (정의·연혁·통계·1차 출처) |
| `background_brief.md` | background-brief 스킬 | 타임라인·인물/기관·쟁점·프레임·공백 |
| `reporting_plan.md` | reporting-plan 스킬 | **취재 계획 + 질문 Q1·Q2·Q3…** ← 2막의 입력 |
| `reporting_plan.html` | reporting-plan 스킬 | 위 내용을 사람이 읽기 좋게 |

가장 중요한 산출물은 **`reporting_plan.md` 안의 번호 붙은 질문 목록**입니다.
이 Q번호가 2막에서 수집 자료와 묶이고, 3막에서 기사 문장의 근거로 이어집니다.

이 파일(README.md)은 폴더를 만들어 두기 위한 것이므로 지워도 됩니다.
