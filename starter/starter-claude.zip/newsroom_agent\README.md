# 1막 스타터 — Claude Code용

이 폴더는 **2차 실습 1막(기획)** 을 바로 시작할 수 있게 설정 파일을 미리 넣어 둔 것입니다.
강의 시작 전에 아래 5단계를 마쳐 두세요. **10분이면 끝납니다.**

---

## 0. 이 폴더를 어디에 둘 것인가

압축을 풀면 `newsroom_agent/` 폴더가 나옵니다. 원하는 위치에 두고 **VS Code에서 File > Open Folder** 로 이 폴더를 여세요.
2·3막까지 계속 쓰는 폴더입니다. 이름을 바꾸거나 지우지 마세요.

---

## 1. 가상환경 만들기 (한 번만)

VS Code에서 터미널을 엽니다. (Terminal > New Terminal, 단축키 `Ctrl` + 백틱)

```bash
# Windows
python -m venv .venv

# macOS / Linux
python3 -m venv .venv
```

## 2. 활성화 (터미널을 새로 열 때마다)

터미널 종류에 따라 명령이 다릅니다.

```bash
# Windows · PowerShell  (입력줄 앞에 PS 가 보임 — VS Code 기본)
.venv\Scripts\Activate.ps1

# Windows · 명령 프롬프트(cmd)  (입력줄이 C:\... > 로 시작)
.venv\Scripts\activate.bat

# macOS / Linux
source .venv/bin/activate
```

입력줄 맨 앞에 `(.venv)` 가 붙으면 성공입니다.

> **PowerShell에서 "이 시스템에서 스크립트를 실행할 수 없으므로…" 오류가 나면**
> 가장 간단한 해결은 **`activate.bat` 을 쓰는 것**입니다. 실행정책 제한을 받지 않습니다.
> ```
> .venv\Scripts\activate.bat
> ```
> PowerShell을 계속 쓰시려면 아래를 **한 번만** 실행한 뒤 다시 활성화하세요.
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
> ```

## 3. 패키지 설치

`(.venv)` 가 켜진 상태에서:

```bash
pip install -r requirements.txt
```

## 4. API 키 넣기

`.env.example` 을 복사해 `.env` 로 만들고, 네이버 키를 채웁니다.

```bash
# Windows PowerShell
Copy-Item .env.example .env

# macOS / Linux
cp .env.example .env
```

받아 오신 키 4개를 채웁니다. 발급 방법은 **사전 준비 안내문**을 보세요.

```
NAVER_CLIENT_ID=네이버에서 받은 Client ID
NAVER_CLIENT_SECRET=네이버에서 받은 Client Secret
DART_API_KEY=DART 메일로 받은 40자리
ASSEMBLY_API_KEY=국회에서 받은 인증키
```

> 등호(`=`) 앞뒤에 공백을 넣지 마세요. 값 뒤에 주석을 붙이지 마세요.

## 5. 동작 확인

```bash
python -c "import requests, dotenv; print('패키지 OK')"
```

`패키지 OK` 가 나오면 준비 끝입니다.

---

## 들어 있는 것

```
newsroom_agent/
├── CLAUDE.md                    취재 규칙 · 작업 순서 · 윤리
├── .env.example                 API 키 서식 (복사해서 .env 로)
├── .gitignore                   .env / .venv 공유 차단
├── requirements.txt             필요 패키지 목록
├── 1_plan/                      1막 산출물이 여기에 쌓입니다
└── .claude/
    ├── agents/
    │   ├── news-archivist.md    과거 기사 수집 담당
    │   └── web-researcher.md    웹 배경 보완 담당
    └── skills/
        ├── background-collect/  뉴스 수집 절차 + collect_news.py
        ├── background-brief/    배경 요약·논리 구성 절차
        └── reporting-plan/      취재 계획 설계 절차
```

---

## 강의 때 첫 명령

폴더에서 `claude` 를 실행한 뒤, 아래 한 줄이면 됩니다. `<주제>` 만 바꾸세요.

```
"해상풍력 인허가와 국산화율" 취재 기획해줘. CLAUDE.md 순서대로 과거 기사 수집 →
웹 배경 보완 → 배경 요약·구성 → 취재 계획 설계까지 진행하고, 단계마다 한 줄로 보고해.
```

---

## 막힐 때

| 증상 | 해결 |
|---|---|
| `(.venv)` 가 안 보임 | 2번 활성화를 다시. PowerShell이 막히면 `.venv\Scripts\activate.bat` 사용 |
| `ModuleNotFoundError` | 활성화 안 된 상태로 실행한 것. `(.venv)` 확인 후 3번 재실행 |
| `KeyError: 'NAVER_CLIENT_ID'` | `.env` 파일이 없거나 키 이름이 다름 |
| `HTTP 401` | 키가 틀렸거나 네이버 애플리케이션에 '검색' API 미추가 |
| `python` 을 못 찾음 | 파이썬 미설치 또는 PATH 누락. 사전 준비 안내문 참고 |

그래도 막히면 **오류 메시지를 그대로 복사해** Claude Code에 붙여넣고
"내 OS는 Windows야. 이 오류 원인과 해결 방법 알려줘" 라고 물어보세요.
