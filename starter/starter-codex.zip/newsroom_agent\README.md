# 1막 스타터 — OpenAI Codex용

이 폴더는 **2차 실습 1막(기획)** 을 바로 시작할 수 있게 설정 파일을 미리 넣어 둔 것입니다.
강의 시작 전에 아래 5단계를 마쳐 두세요. **10분이면 끝납니다.**

> Claude Code를 쓰신다면 이 파일 대신 `starter-claude.zip` 을 받으세요.
> 파이썬 스크립트와 프롬프트는 완전히 같고, **설정 파일 두 종류만 다릅니다.**

---

## 0. 이 폴더를 어디에 둘 것인가

압축을 풀면 `newsroom_agent/` 폴더가 나옵니다. 원하는 위치에 두고 **VS Code에서 File > Open Folder** 로 이 폴더를 여세요.
2·3막까지 계속 쓰는 폴더입니다. 이름을 바꾸거나 지우지 마세요.

---

## 1. 가상환경 만들기 (한 번만)

VS Code에서 터미널을 엽니다. (Terminal > New Terminal, 단축키 `Ctrl` + 백틱)

```bash
# Windows
python -m venv .venv

# macOS / Linux
python3 -m venv .venv
```

## 2. 활성화 (터미널을 새로 열 때마다)

```bash
# Windows · PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate
```

입력줄 맨 앞에 `(.venv)` 가 붙으면 성공입니다.

> **Windows에서 "이 시스템에서 스크립트를 실행할 수 없으므로…" 오류가 나면**
> 아래를 한 번 실행한 뒤 다시 활성화하세요. (한 번만 하면 됩니다)
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
> ```

## 3. 패키지 설치

`(.venv)` 가 켜진 상태에서:

```bash
pip install -r requirements.txt
```

## 4. API 키 넣기

`.env.example` 을 복사해 `.env` 로 만들고, 네이버 키를 채웁니다.

```bash
# Windows PowerShell
Copy-Item .env.example .env

# macOS / Linux
cp .env.example .env
```

키 발급 방법은 **사전 준비 안내문**을 보세요.
1막에서는 **네이버 키 두 개만** 있으면 됩니다. DART·국회 키는 비워 두세요.

## 5. 동작 확인

```bash
python -c "import requests, dotenv; print('패키지 OK')"
```

`패키지 OK` 가 나오면 준비 끝입니다.

---

## 들어 있는 것

```
newsroom_agent/
├── AGENTS.md                    취재 규칙 · 작업 순서 · 윤리
├── .env.example                 API 키 서식 (복사해서 .env 로)
├── .gitignore                   .env / .venv 공유 차단
├── requirements.txt             필요 패키지 목록
├── 1_plan/                      1막 산출물이 여기에 쌓입니다
├── .codex/agents/
│   ├── news-archivist.toml      과거 기사 수집 담당
│   └── web-researcher.toml      웹 배경 보완 담당
└── .agents/skills/
    ├── background-collect/      뉴스 수집 절차 + collect_news.py
    ├── background-brief/        배경 요약·논리 구성 절차
    └── reporting-plan/          취재 계획 설계 절차
```

---

## 강의 때 첫 명령

폴더에서 `codex` 를 실행합니다.

**① 권한을 `workspace-write` 로 설정하세요.**
수집 스크립트가 `1_plan/` 에 파일을 써야 합니다. `read-only` 로는 진행되지 않습니다.
`danger-full-access` / `--yolo` 는 **사용하지 마세요.**

**② 계획을 먼저 봅니다.** `<주제>` 만 바꾸세요.

```
/plan
"해상풍력 인허가와 국산화율" 취재 기획해줘. AGENTS.md 순서대로 과거 기사 수집 →
웹 배경 보완 → 배경 요약·구성 → 취재 계획 설계까지 진행하고, 단계마다 한 줄로 보고해.
```

**③ 계획이 맞으면 실행합니다.**

```
/exec
```

**④ 바뀐 파일을 확인합니다.** Codex는 diff 미리보기가 약하니 이 단계를 건너뛰지 마세요.

```
/diff
```

---

## Codex 사용자만의 주의점

### 스킬이 인식되지 않으면

Codex는 버전에 따라 프로젝트 스킬 경로가 다를 수 있습니다.
`codex` 안에서 `/skills` 를 쳐서 `background-collect` 등이 보이는지 확인하세요.

**보이지 않아도 실습은 그대로 진행됩니다.** 두 가지 방법이 있습니다.

1. `/help` 로 현재 버전의 스킬 경로를 확인해 `.agents/skills/` 를 그 위치로 옮깁니다.
2. 더 간단한 방법 — 세 SKILL.md 의 **본문을 `AGENTS.md` 맨 아래에 붙여넣습니다.**
   절차가 지침에 직접 들어가므로 동작이 같습니다. 강의 중에는 이 방법을 권합니다.

### 서브에이전트가 호출되지 않으면

프롬프트에서 이름을 직접 지정하세요.

```
news-archivist 로 "<주제>" 과거 기사만 수집해줘.
```

그래도 안 되면 서브에이전트 없이도 진행됩니다. `.codex/agents/*.toml` 의
`developer_instructions` 내용을 프롬프트에 그대로 붙여넣으면 같은 결과가 나옵니다.

### 웹 검색이 약할 수 있음

`web-researcher` 는 웹 검색에 의존합니다. 결과가 부실하면 검색 MCP(Tavily·Brave 등)를
`~/.codex/config.toml` 에 추가하세요. **없어도 1막은 완결됩니다** —
과거 기사 수집(네이버 API)만으로 배경 브리프와 질문 목록이 나옵니다.

---

## 막힐 때

| 증상 | 해결 |
|---|---|
| `(.venv)` 가 안 보임 | 2번 활성화를 다시. PowerShell이면 위 실행정책 명령 먼저 |
| `ModuleNotFoundError` | 활성화 안 된 상태로 실행한 것. `(.venv)` 확인 후 3번 재실행 |
| `KeyError: 'NAVER_CLIENT_ID'` | `.env` 파일이 없거나 키 이름이 다름 |
| `HTTP 401` | 키가 틀렸거나 네이버 애플리케이션에 '검색' API 미추가 |
| 파일을 못 씀 | 샌드박스가 `read-only`. `workspace-write` 로 변경 |
| `/skills` 에 안 보임 | 위 "스킬이 인식되지 않으면" 참고 |
| `python` 을 못 찾음 | 파이썬 미설치 또는 PATH 누락. 사전 준비 안내문 참고 |

그래도 막히면 **오류 메시지를 그대로 복사해** Codex에 붙여넣고
"내 OS는 Windows야. 이 오류 원인과 해결 방법 알려줘" 라고 물어보세요.
